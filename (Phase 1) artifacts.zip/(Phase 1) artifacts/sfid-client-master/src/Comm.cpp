#include "Comm.h"

SSL_CTX *Comm::ctx = NULL;

Comm::Comm()
{
    initTLS();
}

Comm &Comm::instance()
{
    static Comm *instance = new Comm();
    return *instance;
}

void Comm::initTLS()
{
    if (ctx == NULL)
    {
#if OPENSSL_API_COMPAT < 0x10100000L
        SSL_library_init();
#else
        OPENSSL_init_ssl(0, NULL);
#endif

        ctx = InitClientCTX();
        const char certFile[] = "leaf.cert.pem";
        const char keyFile[] = "leaf.key.pem";
        const char caFile[] = "ca-chain.cert.pem";
        SSL_LoadCert(ctx, certFile, keyFile, caFile); /* load certs */
    }
}

void Comm::setVideo(Video *video)
{
    this->video = video;
}

bool Comm::connect(const char *ip, const char *port, const bool tls)
{
    if ((TcpConnectedPort = OpenTcpConnection(ip, port)) != NULL)
    {
        std::cout << "OpenTcpConnection succeed" << std::endl;
    }
    else
    {
        std::cout << "OpenTcpConnection failed" << std::endl;
        return false;
    }

    if (tls)
    {
        ssl = SSL_new(ctx); /* create new SSL connection state */

        SSL_set_fd(ssl, TcpConnectedPort->ConnectedFd); /* attach the socket descriptor */

        if (SSL_connect(ssl) == -1) /* perform the connection */
        {
            fprintf(stderr, "SSL Connect Failes for port:%s sockFd: %d\n", port, TcpConnectedPort->ConnectedFd);
            ERR_print_errors_fp(stderr);

            std::cout << "OpenTlsConnection failed" << std::endl;
            return false;
        }

        std::cout << "OpenTlsConnection succeed" << std::endl;
    }
}

void Comm::close()
{
    CloseTcpConnectedPort(&TcpConnectedPort);

    if (ssl != NULL)
    {
        SSL_free(ssl); /* release connection state */
                       //        SSL_CTX_free(ctx);
    }
}
