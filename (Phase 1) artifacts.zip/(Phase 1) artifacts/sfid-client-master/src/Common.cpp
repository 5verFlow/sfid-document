#include "Common.h"

#include <stddef.h>

bool isJpegFormat(unsigned char *buff, int sz)
{
    if (buff == NULL)
        return false;

    // SOI (Start of Image) check
    if (buff[0] != 0xFF || buff[1] != 0xD8)
    {
        return false;
    }

    // EOI (End of Image) check
    if (buff[sz - 2] != 0xFF || buff[sz - 1] != 0xD9)
    {
        return false;
    }

    return true;
}
