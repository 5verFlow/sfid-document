#include "Video.h"

#include <opencv2/imgproc/imgproc.hpp>

Video::Video()
{
}

Video &Video::instance()
{
    static Video *instance = new Video();
    return *instance;
}

void Video::cppSlotStartVideo()
{
    std::cout << "cppSlotStartVideo call" << std::endl;

    openWindow();
}

void Video::cppSlotStopVideo()
{
    std::cout << "cppSlotStopVideo call" << std::endl;

    closeWindow();
}

void Video::cppSlotShowImage()
{
    //    std::cout << "cppSlotShowImage call" << std::endl;

    embedFaceRegionToImage();
    showImage();
    clearFaceRegion();
}

cv::Mat *Video::getImgBuffer()
{
    return &(this->imgBuffer);
}

std::vector<struct FaceRegion> *Video::getFaceRegion()
{
    return &(this->faceRegion);
}

int *Video::getCountUnknown()
{
    return &(this->countUnknown);
}

void Video::openWindow()
{
    cv::namedWindow("Video", cv::WINDOW_AUTOSIZE);
}

void Video::showImage()
{
    cv::imshow("Video", imgBuffer);
}

void Video::closeWindow()
{
    cv::destroyWindow("Video");
}

void Video::embedFaceRegionToImage()
{
    if (faceRegion.empty())
        return;

    for (int i = 0; i < faceRegion.size(); i++)
    {
        cv::Scalar color;
        if (faceRegion[i].isRegistered)
            color = cv::Scalar(0, 255, 255); // yellow for recognized
        else
            color = cv::Scalar(0, 0, 255); // read for unknown

        cv::rectangle(imgBuffer, cv::Point(faceRegion[i].y1, faceRegion[i].x1), cv::Point(faceRegion[i].y2, faceRegion[i].x2), color, 2, 8, 0);
        std::string strName(faceRegion[i].userName);
        float fontScaler = static_cast<float>(faceRegion[i].x2 - faceRegion[i].x1) / static_cast<float>(640);

        cv::putText(imgBuffer, strName, cv::Point(faceRegion[i].y1 + 2, faceRegion[i].x2 - 3), cv::FONT_HERSHEY_COMPLEX_SMALL, 0.1 + 2 * fontScaler * 4, color, 1); //FONT_HERSHEY_DUPLEX
    }
}

void Video::clearFaceRegion()
{
    faceRegion.clear();
}
