//------------------------------------------------------------------------------------------------
// File: SecureCTX.cpp
// Project: LG Exec Ed Program
// Versions:
// 1.0 June 2021 - initial version
// Create Context and load certificates for TLS
//------------------------------------------------------------------------------------------------
#include "SecureCTX.h"

SSL_CTX *InitClientCTX(void)
{
#if OPENSSL_API_COMPAT < 0x10100000L
    OpenSSL_add_all_algorithms();
    SSL_load_error_strings(); /* Bring in and register error messages */
#endif

    const SSL_METHOD *method = TLS_client_method(); /* Create new client-method instance */
    SSL_CTX *ctx = SSL_CTX_new(method);             /* Create new context */
    if (ctx == NULL)
    {
        ERR_print_errors_fp(stderr);
        abort();
    }

    return ctx;
}

SSL_CTX *InitServerCTX(void)
{
    SSL_CTX *ctx;
#if OPENSSL_API_COMPAT < 0x10100000L
    OpenSSL_add_all_algorithms(); /* load & register all cryptos, etc. */
    SSL_load_error_strings();     /* load all error messages */
#endif
    const SSL_METHOD *method = TLS_server_method(); /* create new server-method instance */
    ctx = SSL_CTX_new(method);                      /* create new context from method */
    if (ctx == NULL)
    {
        ERR_print_errors_fp(stderr);
        abort();
    }
    return ctx;
}

void SSL_LoadCert(SSL_CTX *ctx, const char *CertFile, const char *KeyFile, const char *CaFile)
{
    /* set the local certificate from CertFile */
    if (SSL_CTX_use_certificate_file(ctx, CertFile, SSL_FILETYPE_PEM) <= 0)
    {
        ERR_print_errors_fp(stderr);
        abort();
    }

    /* set the private key from KeyFile (may be the same as CertFile) */
    if (SSL_CTX_use_PrivateKey_file(ctx, KeyFile, SSL_FILETYPE_PEM) <= 0)
    {
        ERR_print_errors_fp(stderr);
        abort();
    }

    /* verify private key */
    if (!SSL_CTX_check_private_key(ctx))
    {
        fprintf(stderr, "Private key does not match the public certificate\n");
        abort();
    }

    if (!SSL_CTX_load_verify_locations(ctx, CaFile, nullptr))
    {
        fprintf(stderr, "Verify Location Failure\n");
        abort();
    }

    /* Set to require peer (client) certificate verification. */
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);
    /* Set the verification depth to 5 */
    SSL_CTX_set_verify_depth(ctx, 5);
}

#ifdef LOG_OPENSSL
CTLOG_STORE *ctlog_store = NULL;

void CT_Log_Start(void)
{
    if ((ctlog_store = CTLOG_STORE_new()) == NULL)
    {
        CTLOG_STORE_load_default_file(ctlog_store);
    }
}

void CT_Log_Stop(void)
{
    if (ctlog_store != NULL)
        CTLOG_STORE_free(ctlog_store);
    ctlog_store = NULL;
}
#endif

//-----------------------------------------------------------------
// END of File
//-----------------------------------------------------------------
