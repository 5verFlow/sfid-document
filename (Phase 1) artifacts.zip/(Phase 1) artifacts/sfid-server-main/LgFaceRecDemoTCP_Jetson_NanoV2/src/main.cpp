#include <iostream>
#include <string>
#include <cstring>
#include <chrono>
#include <NvInfer.h>
#include <NvInferPlugin.h>
#include <l2norm_helper.h>
#include <opencv2/core/cuda.hpp>
#include <opencv2/cudawarping.hpp>
#include <bsd/string.h>
#include "faceNet.h"
#include "videoStreamer.h"
#include "network.h"
#include "mtcnn.h"
#include "sflog.hpp"

#include "NetworkTCP.h"
#include "TcpSendRecvJpeg.h"
#include <termios.h>

#include <unistd.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <thread>
#include <atomic>

#include<sys/types.h>
#include<netinet/in.h>
#include<pthread.h>

#include <algorithm>
#include <signal.h>	// for seg fault
#include "SecureCtx.h"
#include "SecureTCP.h"
#include "common.h"

#define 	BUF_SIZE		512
//#define 	NAME_LEN		100

static const	int videoFrameWidth = 640;
static const	int videoFrameHeight = 480;
static const	bool isCSICam = true;
std::atomic_int operationMode(0);
std::atomic_int prev_operationMode(0);

std::atomic_int tcp_img_user_num(0);
std::atomic_int tcp_data_user_num(0);
std::atomic_int tls_img_user_num(0);
std::atomic_int tls_data_user_num(0);

using namespace sfid::sflog;

char nameToRegister[MAX_NAME_LEN]; //flawfinder_5verflow : ignore - perform bounds checking

typedef struct
{
	pthread_t		pid;
	CONN_MODE		mode;
	TTcpConnectedPort*	TcpConnectedPort;
	SSL*			ssl;
	SSL_CTX*		ctx;
} TConnCli;


typedef struct
{
	CONN_MODE		mode;
	bool			UseCamera;
	VideoStreamer*		videoStreamer;
	std::vector<struct Bbox>* outputBbox;
	mtcnn*			mtCNN;
	FaceNetClassifier*	faceNet;
	TTcpConnectedPort*	TcpConnectedPort;
	SSL*			ssl;
	SSL_CTX*			ctx;

} TProcImg;


TConnCli		_ConnCli[2];	// Two rooms for TCP and TLS
TProcImg		_ProcImg[2];	// Two rooms for TCP and TLS

int isRoot()
{
    if (getuid() != 0)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

int kbhit()
{
    struct timeval tv = { 0L, 0L };
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(0, &fds);
    return select(1, &fds, NULL, NULL, &tv);
}

int getch()
{
    int r;
    unsigned char c;
    if ((r = read(0, &c, sizeof(c))) < 0) { //flawfinder_5verflow : ignore
        return r;
    } else {
        return c;
    }
}
#ifdef SEND_METADATA
void printSendData(std::vector<struct FaceRegion> fr, int frameNum){
	printf("--------------\n");
	printf("frame number: %d, # of Face: %ld\n", frameNum, fr.size());
	int sz = 0;
	for(int i = 0; i < fr.size(); i++){

		std::cout << fr[i].userName << ", "
			<< fr[i].x1 << ", " << fr[i].y1 << ", "
			<< fr[i].x2 << ", " << fr[i].y2 << std::endl;
		sz += sizeof(FaceRegion);
	}
	printf("total size: %d\n", sz);
	frameNum++;

}
#endif

void* process_image(void *arg)
{
	int nbFrames = 0;
	cv::Mat frame;
	TProcImg* _procImg = (TProcImg*)arg;
	bool UseCamera = _procImg->UseCamera;
	//VideoStreamer* videoStreamer = _procImg->videoStreamer;
	std::vector<struct Bbox> outputBbox = *(_procImg->outputBbox);
	mtcnn	mtCNN = *(_procImg->mtCNN);
	FaceNetClassifier faceNet = *(_procImg->faceNet);
	TTcpConnectedPort* TcpConnectedPort = _procImg->TcpConnectedPort;
	SSL*	ssl = _procImg->ssl;
	CONN_MODE mode = _procImg->mode;

	VideoStreamer *videoStreamer = NULL;
	// init opencv stuff
	if (UseCamera)  videoStreamer = new VideoStreamer(0, videoFrameWidth, videoFrameHeight, 60, isCSICam);
	else videoStreamer = new VideoStreamer("../friends640x480.mp4", videoFrameWidth, videoFrameHeight);

	printf("UseCamera = %d, video width = %d, height = %d, isCSICam = %d\n", UseCamera, videoFrameWidth, videoFrameHeight, isCSICam);

	cv::cuda::GpuMat src_gpu, dst_gpu;
	cv::Mat dst_img;
	// loop over frames with inference
	auto globalTimeStart = chrono::steady_clock::now();

#ifdef SEND_METADATA
	// Initialize face region
	std::vector<struct FaceRegion> faceRegion;
//	faceRegion.reserve(maxFacesPerScene);
#endif

	while (true) {
		videoStreamer->getFrame(frame);
		if (frame.empty()) {
			std::cout << "Empty frame! Exiting...\n Try restarting nvargus-daemon by "
			"doing: sudo systemctl restart nvargus-daemon" << std::endl;
			break;
		}
		// Create a destination to paint the source into.
		dst_img.create(frame.size(), frame.type());

		// Push the images into the GPU
		if (UseCamera) {
			src_gpu.upload(frame);
			cv::cuda::rotate(src_gpu, dst_gpu, src_gpu.size(), 180, src_gpu.size().width, src_gpu.size().height);
			dst_gpu.download(frame);
		}

		// MTCNN - Find Face
		auto startMTCNN = chrono::steady_clock::now();
		outputBbox = mtCNN.findFace(frame);
		auto endMTCNN = chrono::steady_clock::now();

		// FaceNet - get Feature values from cropped images
		auto startForward = chrono::steady_clock::now();
		faceNet.forward(frame, outputBbox);
		auto endForward = chrono::steady_clock::now();

		// FaceNet - Feature Matching
		auto startFeatM = chrono::steady_clock::now();
#ifdef SEND_METADATA
		faceNet.featureMatching(frame, faceRegion);
#else
		faceNet.featureMatching(frame);
#endif
		auto endFeatM = chrono::steady_clock::now();
		faceNet.resetVariables();

#ifdef SEND_METADATA
		//for test
		//printSendData(faceRegion, nbFrames);

        if(ssl) {
			if (SSL_TcpSendFaceData(ssl, TcpConnectedPort, frame, faceRegion)<0)  break;
		} else {
			if (TcpSendFaceData(TcpConnectedPort, frame, faceRegion)<0)  break;
		}
		faceRegion.clear();
#else
        if(ssl) {
			if (SSL_TcpSendImageAsJpeg(ssl, TcpConnectedPort,frame)<0)  break;
		} else {
			if (TcpSendImageAsJpeg(TcpConnectedPort,frame)<0)  break;
		}
#endif

		nbFrames++;
		outputBbox.clear();
		frame.release();

		if(prev_operationMode != operationMode) {
			if (operationMode == E_MODE_LIVE && prev_operationMode == E_MODE_PLAYBACK) {
				delete videoStreamer;
				UseCamera = true;
				videoStreamer = new VideoStreamer(0, videoFrameWidth, videoFrameHeight, 60, isCSICam);
			}
			else if ( operationMode == E_MODE_ADD_USER ){
				auto dTimeStart = chrono::steady_clock::now();
				videoStreamer->getFrame(frame);
				// Create a destination to paint the source into.
				dst_img.create(frame.size(), frame.type());
				// Push the images into the GPU
				src_gpu.upload(frame);
				cv::cuda::rotate(src_gpu, dst_gpu, src_gpu.size(), 180, src_gpu.size().width, src_gpu.size().height);
				dst_gpu.download(frame);
				outputBbox = mtCNN.findFace(frame);

				if (ssl) {
					if (SSL_TcpSendImageAsJpeg(ssl, TcpConnectedPort,frame)<0)  break;
				} else {
					if (TcpSendImageAsJpeg(TcpConnectedPort,frame)<0)  break;
				}

				faceNet.addNewFacebyNet(frame, outputBbox, nameToRegister);
				auto dTimeEnd = chrono::steady_clock::now();
				globalTimeStart += (dTimeEnd - dTimeStart);
				operationMode = E_MODE_REGISTER;

			} else if (operationMode == E_MODE_PLAYBACK ) {
				//videoStreamer->release();		// TODO- CHECK!
				delete videoStreamer;
				UseCamera = false;
				videoStreamer = new VideoStreamer("../friends640x480.mp4", videoFrameWidth, videoFrameHeight);
			}
			prev_operationMode.store(operationMode);
		}

		if (kbhit()) {
			// Stores the pressed key in ch
			char keyboard =  getch();

			if (keyboard == 'q') break;
		}
#ifdef LOG_TIMES
		std::cout << "mtCNN took " << std::chrono::duration_cast<chrono::milliseconds>(endMTCNN - startMTCNN).count() << "ms\n";
		std::cout << "Forward took " << std::chrono::duration_cast<chrono::milliseconds>(endForward - startForward).count() << "ms\n";
		std::cout << "Feature matching took " << std::chrono::duration_cast<chrono::milliseconds>(endFeatM - startFeatM).count() << "ms\n\n";
#endif  // LOG_TIMES
	}
	auto globalTimeEnd = chrono::steady_clock::now();
	printf("TRY TO RELEASE VSTREAMER\n");

	//videoStreamer->release(); // TODO- CHECK!
	delete videoStreamer;
	printf("VSTREAMER RELEASED\n");
	auto milliseconds = chrono::duration_cast<chrono::milliseconds>(globalTimeEnd-globalTimeStart).count();
	double seconds = double(milliseconds)/1000.;
	double fps = nbFrames/seconds;

	std::cout << "Counted " << nbFrames << " frames in " << double(milliseconds)/1000. << " seconds!" <<
		" This equals " << fps << "fps.\n";

	if(mode == E_CONN_TLS){
		close(SSL_get_fd(ssl));          /* close connection */
		//SSL_CTX_free(ctx);         /* release context */
		SSL_free(ssl);         /* release SSL state */
		tls_img_user_num--;
	} else {
		tcp_img_user_num--;
	}
}


void* socketChat(void *arg){
	// find if same connFd exist
	// if exist do send video

	unsigned char buffer[BUF_SIZE] = {0}; //flawfinder_5verflow : ignore - perform bounds checking
	int retval;
	TConnCli* pConnCli = (TConnCli*) arg;
	//int clientfd = pConnCli->connFd;
	TTcpConnectedPort* TcpConnectedPort = pConnCli->TcpConnectedPort;
	int clientfd = TcpConnectedPort->ConnectedFd;
	CONN_MODE mode = pConnCli->mode;
	SSL*	ssl = pConnCli->ssl;

	printf("socketChat\n");
	while(1){
		memset(buffer, 0, BUF_SIZE);
		if (mode == E_CONN_TCP) {
			retval = ReadDataTcp(TcpConnectedPort, buffer, BUF_SIZE);

		} else {
			retval = SSL_ReadDataTcp(ssl, TcpConnectedPort, buffer, BUF_SIZE);
		}
		//retval = read(clientfd, buffer, BUF_SIZE);

		if(retval < 0){
			printf("Reading Error\n");
			break;
		}

		TClientMsg* p_recvData = (TClientMsg*)&buffer;
		TClientMsg recvData = *p_recvData;
		recvData.msgType = ntohs(recvData.msgType);
		recvData.dataLen = ntohs(recvData.dataLen);

		printf("received msgtype = %d, datalen = %d\n", recvData.msgType, recvData.dataLen);

		if (recvData.msgType == E_MSG_LIVE) {
			// TODO : LIVE VIDEO IF CURRENT MODE IS PLAYBACK
			operationMode = E_MODE_LIVE;
			printf("Server Mode: LIVE\n");
		} else if (recvData.msgType == E_MSG_PLAYBACK ) {
			// TODO: PLAYBACK VIDEO IF CURRENT MODE IS LIVE
			operationMode = E_MODE_PLAYBACK;
			printf("Server Mode: PLAYBACK\n");
		} else if (recvData.msgType == E_MSG_REGISTER ) {
			operationMode = E_MODE_REGISTER;
			printf("Server Mode: REGISTER\n");
		} else if (recvData.msgType == E_MSG_ADD_USER ) {
			if(recvData.dataLen > 0 || recvData.dataLen < MAX_NAME_LEN) {
				memset(nameToRegister, 0, sizeof(nameToRegister));
				printf("datalen = %d\n", recvData.dataLen);
				strlcpy(nameToRegister, (char*)(buffer + sizeof(TClientMsg)), recvData.dataLen); //flawfinder_5verflow
				printf("name to register = %s\n", nameToRegister);
				operationMode = E_MODE_ADD_USER;
			} else {
				printf("invalid size of datalen = %d\n", recvData.dataLen);
			}
		} else {
			printf("Invalid MsgType = %d", recvData.msgType);
		}

/*
		// TODO: Send Response
		memset(buffer, 0, BUF_SIZE);
		if (mode == E_CONN_TCP) {
			retval = WriteDataTcp(TcpConnectedPort, buffer, sizeof(buffer));
		} else {
			retval = SSL_WriteDataTcp(ssl, TcpConnectedPort, buffer, sizeof(buffer));
		}
*/
		//retval =  write(clientfd, temp, sizeof(temp));
		if(retval < 0) {
			printf("Writing Error\n");
			break;
		}
	}
	if(mode == E_CONN_TLS){
		close(SSL_get_fd(ssl));          /* close connection */
		//SSL_CTX_free(ctx);         /* release context */
		SSL_free(ssl);         /* release SSL state */
		tls_data_user_num--;
	} else {
		tcp_data_user_num--;
	}
}



// Uncomment to print timings in milliseconds
// #define LOG_TIMES

using namespace nvinfer1;
using namespace nvuffparser;

int main(int argc, char *argv[])
{
	static const short _TcpListenPort = 5000;
	static const short _TcpListenPort2 = 5001;
	static const short _TlsListenPort = 6000;
	static const short _TlsListenPort2 = 6001;

	SFLogger img_log(LIMG);
	SFLogger comm_log(LCOM);
	SFLogger conn_log(LCON);


	//std::atomic_int numOfConnectedUsers(0);

	bool	UseCamera = true;
	if (argc <1)  {
		fprintf(stderr,"usage %s [filename]\n", argv[0]);
		exit(0);
	}
	if (argc!=1)	UseCamera = false;
	Logger gLogger = Logger();
	// Register default TRT plugins (e.g. LRelu_TRT)
	if (!initLibNvInferPlugins(&gLogger, "")) { return 1; }

	// USER DEFINED VALUES
	const string uffFile="../facenetModels/facenet.uff";
	const string engineFile="../facenetModels/facenet.engine";
	DataType dtype = DataType::kHALF;
	//DataType dtype = DataType::kFLOAT;
	bool serializeEngine = true;
	int batchSize = 1;

	int maxFacesPerScene = 8;
	float knownPersonThreshold = 1.;

	// init facenet
	FaceNetClassifier faceNet = FaceNetClassifier(gLogger, dtype, uffFile, engineFile, batchSize, serializeEngine,
		knownPersonThreshold, maxFacesPerScene, videoFrameWidth, videoFrameHeight);

	VideoStreamer *videoStreamer = NULL;

	// init mtCNN
	mtcnn mtCNN(videoFrameHeight, videoFrameWidth);

	//init Bbox and allocate memory for "maxFacesPerScene" faces per scene
	std::vector<struct Bbox> outputBbox;
	outputBbox.reserve(maxFacesPerScene);

	// get embeddings of known faces
	std::vector<struct Paths> paths;
	cv::Mat image;
	getFilePaths(getCryptPath("imgs"), paths);
	for(int i=0; i < paths.size(); i++) {
		loadInputImage(paths[i].absPath, image, videoFrameWidth, videoFrameHeight);
		if(image.empty()){
			std::cout << "File read failed : NOT an image format - " << paths[i].absPath << std::endl;
			continue;
		}

		outputBbox = mtCNN.findFace(image);
		std::size_t index = paths[i].fileName.find_last_of(".");
		std::string rawName = paths[i].fileName.substr(0,index);
		faceNet.forwardAddFace(image, outputBbox, rawName);
		faceNet.resetVariables();
	}
	outputBbox.clear();

	if(!isRoot()) {
		printf("This program must be run as root/sudo user!!\n");
		//exit(EXIT_SUCCESS);
	}

	signal(SIGPIPE, SIG_IGN);
	SSL* p_ssl[2];

	// Run servers
	auto tcpThread = std::thread([&]() {
		TTcpListenPort    *TcpListenPort;
		TTcpConnectedPort *TcpConnectedPort;
		struct sockaddr_in cli_addr;
		socklen_t          clilen;

		if ((TcpListenPort=OpenTcpListenPort(_TcpListenPort))==NULL)  // Open TCP Network port
		{
			conn_log.err("OpenTcpListenPortFailed\n");
			printf("OpenTcpListenPortFailed\n");
			return(-1);
		}
		conn_log.noti("Listening for TCP connection: Control Port\n");
		printf("Listening for TCP connection: Control Port\n");

		while (1) {
			clilen = sizeof(cli_addr);
			if ((TcpConnectedPort=AcceptTcpConnection(TcpListenPort,&cli_addr,&clilen))==NULL) {
				conn_log.noti("AcceptTcpConnection Failed\n");
				printf("AcceptTcpConnection Failed\n");
				return(-1);
			} else {
				if (tcp_data_user_num == 0) {
					_ConnCli[0].mode = E_CONN_TCP;
					_ConnCli[0].TcpConnectedPort = TcpConnectedPort;	// C90?
					_ConnCli[0].ssl = NULL;
					conn_log.info("Connection: %s:%d, TCP Control Port\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
					printf("Connection: %s:%d, TCP Control Port\n", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
					pthread_create(&_ConnCli[0].pid, NULL, &socketChat, (void*)&_ConnCli[0]);
					tcp_data_user_num++;
				} else {
					conn_log.err("Support for only 1 connection\n");
					printf("Support for only 1 connection\n");
					close(TcpConnectedPort->ConnectedFd);
				}
			}
		}

	});

	auto tcpThread2 = std::thread([&]() {
		TTcpListenPort    *TcpListenPort;
		TTcpConnectedPort *TcpConnectedPort;
		struct sockaddr_in cli_addr;
		socklen_t          clilen;

		if ((TcpListenPort=OpenTcpListenPort(_TcpListenPort2))==NULL)  // Open TCP Network port
		{
			conn_log.err("OpenTcpListenPortFailed\n");
			printf("OpenTcpListenPortFailed\n");

			return(-1);
		}
		conn_log.noti("Listening for TCP connection: Image Port\n");
		printf("Listening for TCP connection: Image Port\n");

		while (1) {
			clilen = sizeof(cli_addr);
			if ((TcpConnectedPort=AcceptTcpConnection(TcpListenPort,&cli_addr,&clilen))==NULL) {
				conn_log.noti("AcceptTcpConnection Failed\n");
				printf("AcceptTcpConnection Failed\n");
				return(-1);
			} else if (tcp_img_user_num == 0) {
				_ProcImg[0].mode = E_CONN_TCP;
				_ProcImg[0].UseCamera = UseCamera;
				_ProcImg[0].videoStreamer = videoStreamer;
				_ProcImg[0].outputBbox = &outputBbox;
				_ProcImg[0].mtCNN		= &mtCNN;
				_ProcImg[0].faceNet	= &faceNet;
				_ProcImg[0].TcpConnectedPort = TcpConnectedPort;
				conn_log.info("Connection: %s:%d\n, TCP Image and Metadata Port", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
				printf("Connection: %s:%d\n, TCP Image and Metadata Port", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));

				pthread_create(&_ConnCli[0].pid, NULL, &process_image, (void*)&_ProcImg[0]);
				tcp_img_user_num++;
			} else {
				conn_log.err("Support for only 1 connection\n");
				printf("Support for only 1 connection\n");
				close(TcpConnectedPort->ConnectedFd);
			}
		}
	});


#ifdef LOG_OPENSSL
	CT_Log_Start();
#endif

# if OPENSSL_API_COMPAT < 0x10100000L
	SSL_library_init();
#else
	OPENSSL_init_ssl(0, NULL);
#endif

    SSL_CTX *ctx = InitServerCTX();        /* initialize SSL */
    std::string certFile = getCryptPath("ca/intermediate/certs/");
    std::string keyFile = getCryptPath("ca/intermediate/private/");
    std::string caFile = getCryptPath("ca/certs/");

    certFile.append("intermediate.cert.pem");
    keyFile.append("intermediate.key.pem");
    caFile.append("ca.cert.pem");
    SSL_LoadCert(ctx, (const char*)certFile.c_str(), (const char*)keyFile.c_str(), (const char*)caFile.c_str()); /* load certs */


	auto tlsThread = std::thread([&]() {
		TTcpListenPort    *TlsListenPort;
		TTcpConnectedPort *TlsConnectedPort;
		struct sockaddr_in		tls_cli_addr;
		socklen_t			tls_clilen;

		p_ssl[0] = SSL_new(ctx);              /* get new SSL state with context */

		if ((TlsListenPort=OpenTcpListenPort(_TlsListenPort))==NULL)  // Open TCP Network port
		{
			conn_log.err("OpenTcpListenPortFailed\n");
			printf("OpenTcpListenPortFailed\n");
			return(-1);
		}
		conn_log.noti("Listening for TLS connections\n");
		printf("Listening for TLS connection:  Control Port\n");

		while (1) {
			tls_clilen = sizeof(tls_cli_addr);
			if ((TlsConnectedPort=AcceptTcpConnection(TlsListenPort,&tls_cli_addr,&tls_clilen))==NULL) {
				conn_log.err("AcceptTcpConnection Failed\n");
				printf("AcceptTcpConnection Failed\n");
				return(-1);
			} else {
				SSL_set_fd(p_ssl[0], TlsConnectedPort->ConnectedFd);      /* set connection socket to SSL state */
				if( SSL_accept(p_ssl[0]) < 1 ) {
					ERR_print_errors_fp(stderr);
				} else {
					if(tls_data_user_num == 0) {
						_ConnCli[1].mode = E_CONN_TLS;
						_ConnCli[1].TcpConnectedPort = TlsConnectedPort;	// C90?
						_ConnCli[1].ssl = p_ssl[0];
						_ConnCli[1].ctx = ctx;
						conn_log.info("Connection: %s:%d, TLS Control Port\n", inet_ntoa(tls_cli_addr.sin_addr), ntohs(tls_cli_addr.sin_port));
						printf("Connection: %s:%d, TLS Control Port\n", inet_ntoa(tls_cli_addr.sin_addr), ntohs(tls_cli_addr.sin_port));
						pthread_create(&_ConnCli[1].pid, NULL, &socketChat, (void*)&_ConnCli[1]);
						tls_data_user_num++;
					} else {
						conn_log.err("Support for only 1 connection\n");
						printf("Support for only 1 connection\n");
						close(TlsConnectedPort->ConnectedFd);
					}
				}
			}
		}
	});


	auto tlsThread2 = std::thread([&]() {
		TTcpListenPort    *TlsListenPort;
		TTcpConnectedPort *TlsConnectedPort;
		struct sockaddr_in		tls_cli_addr;
		socklen_t			tls_clilen;


		p_ssl[1] = SSL_new(ctx);              /* get new SSL state with context */

		if ((TlsListenPort=OpenTcpListenPort(_TlsListenPort2))==NULL)  // Open TCP Network port
		{
			conn_log.err("OpenTcpListenPortFailed\n");
			printf("OpenTcpListenPortFailed\n");
			return(-1);
		}
		conn_log.noti("Listening for TLS connection: Image Port\n");
		printf("Listening for TLS connection: Image Port\n");

		while (1 ) {
			tls_clilen = sizeof(tls_cli_addr);
			if ((TlsConnectedPort=AcceptTcpConnection(TlsListenPort,&tls_cli_addr,&tls_clilen))==NULL) {
				conn_log.err("AcceptTcpConnection Failed\n");
				printf("AcceptTcpConnection Failed\n");
				return(-1);
			} else {
				SSL_set_fd(p_ssl[1], TlsConnectedPort->ConnectedFd);      /* set connection socket to SSL state */
				if( SSL_accept(p_ssl[1]) < 1 ) {
					ERR_print_errors_fp(stderr);
				} else {
					if(tls_img_user_num == 0) {
						_ProcImg[1].mode = E_CONN_TLS;
						_ProcImg[1].UseCamera = UseCamera;
						_ProcImg[1].videoStreamer = videoStreamer;
						_ProcImg[1].outputBbox = &outputBbox;
						_ProcImg[1].mtCNN	= &mtCNN;
						_ProcImg[1].faceNet	= &faceNet;
						_ProcImg[1].TcpConnectedPort = TlsConnectedPort;
						_ProcImg[1].ssl = p_ssl[1];
						_ProcImg[1].ctx = ctx;

						conn_log.info("Connection: %s:%d, TLS Image and Metadata Port\n", inet_ntoa(tls_cli_addr.sin_addr), ntohs(tls_cli_addr.sin_port));
						printf("Connection: %s:%d, TLS Image and Metadata Port\n", inet_ntoa(tls_cli_addr.sin_addr), ntohs(tls_cli_addr.sin_port));
						pthread_create(&_ConnCli[1].pid, NULL, &process_image, (void*)&_ProcImg[1]);
						tls_img_user_num++;
					} else {
						conn_log.err("Support for only 1 connection\n");
						printf("Support for only 1 connection\n");
						close(TlsConnectedPort->ConnectedFd);
					}
				}
			}
		}
	});

	tcpThread.join();
	tcpThread2.join();
	tlsThread.join();
	tlsThread2.join();


#ifdef LOG_OPENSSL
		//CT_Log_Stop();
#endif

}


