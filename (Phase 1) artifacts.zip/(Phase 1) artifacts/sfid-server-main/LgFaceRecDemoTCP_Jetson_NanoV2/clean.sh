rm mtCNNModels/*.engine
rm facenetModels/*.engine
rm -rf build


