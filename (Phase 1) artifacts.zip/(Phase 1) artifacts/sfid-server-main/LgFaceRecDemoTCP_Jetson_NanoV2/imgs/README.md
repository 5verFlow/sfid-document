# Image directory
This folder contains images of people you would like to recognize. The
format of picture should *class_name*.jpg.