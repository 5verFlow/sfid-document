#include "sflog.hpp"


// please refer /etc/rsyslog.d/50-default.conf
// there is definition for sfid log like following
// local0.*         /var/log/sfid.log

using namespace sfid::sflog;

int main () {
    SFLogger img(LIMG);
    SFLogger comm(LCOM);
    SFLogger conn(LCON);

    img.noti("hello img\n");
    comm.noti("hello comm %d\n", 2);
    conn.noti("hello conn %d %s\n", 3, "hoho");

    return 0;
}
