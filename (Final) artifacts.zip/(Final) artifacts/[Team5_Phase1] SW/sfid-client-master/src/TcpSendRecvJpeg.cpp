//------------------------------------------------------------------------------------------------
// File: TcpSendRecvJpeg.cpp
// Project: LG Exec Ed Program
// Versions:
// 1.0 April 2017 - initial version
// Send and receives OpenCV Mat Images in a Tcp Stream commpressed as Jpeg images
//------------------------------------------------------------------------------------------------
#include <opencv2/highgui/highgui.hpp>

#include "TcpSendRecvJpeg.h"

static int init_values[2] = {cv::IMWRITE_JPEG_QUALITY, 80}; //default(95) 0-100
static std::vector<int> param(&init_values[0], &init_values[0] + 2);
static std::vector<uchar> sendbuff; //buffer for coding

static std::vector<uchar> imgbuff;  //buffer for coding
static std::vector<uchar> databuff; //buffer to send data thru network

//-----------------------------------------------------------------
// TcpSendImageAsJpeg - Sends a Open CV Mat Image commressed as a
// jpeg image in side a TCP Stream on the specified TCP local port
// and Destination. return bytes sent on success and -1 on failure
//-----------------------------------------------------------------
int TcpSendImageAsJpeg(TTcpConnectedPort *TcpConnectedPort, cv::Mat Image)
{
    unsigned int imagesize;
    cv::imencode(".jpg", Image, sendbuff, param);
    imagesize = htonl(sendbuff.size()); // convert image size to network format
    if (WriteDataTcp(TcpConnectedPort, (unsigned char *)&imagesize, sizeof(imagesize)) != sizeof(imagesize))
        return (-1);
    return (WriteDataTcp(TcpConnectedPort, sendbuff.data(), sendbuff.size()));
}
//-----------------------------------------------------------------
// END TcpSendImageAsJpeg
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// TcpRecvImageAsJpeg - Sends a Open CV Mat Image commressed as a
// jpeg image in side a TCP Stream on the specified TCP local port
// returns true on success and false on failure
//-----------------------------------------------------------------
bool TcpRecvImageAsJpeg(TTcpConnectedPort *TcpConnectedPort, cv::Mat *Image)
{
    unsigned int imagesize;
    unsigned char *buff; /* receive buffer */

    if (ReadDataTcp(TcpConnectedPort, (unsigned char *)&imagesize, sizeof(imagesize)) != sizeof(imagesize))
        return (false);

    imagesize = ntohl(imagesize); // convert image size to host format

    if (imagesize < 0)
        return false;

    buff = new (std::nothrow) unsigned char[imagesize];
    if (buff == NULL)
        return false;

    if ((ReadDataTcp(TcpConnectedPort, buff, imagesize)) == imagesize)
    {
        cv::imdecode(cv::Mat(imagesize, 1, CV_8UC1, buff), cv::IMREAD_COLOR, Image);
        delete[] buff;
        if (!(*Image).empty())
            return true;
        else
            return false;
    }
    delete[] buff;
    return false;
}
//-----------------------------------------------------------------
// END TcpRecvImageAsJpeg
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// TcpSendFaceData - Sends a Open CV Mat Image commressed as a
// jpeg image and face region data in side a TCP Stream on the specified TCP local port
// and Destination. return bytes sent on success and -1 on failure
//-----------------------------------------------------------------
int TcpSendFaceData(TTcpConnectedPort *TcpConnectedPort, cv::Mat Image, std::vector<struct FaceRegion> fr)
{
    unsigned int datasize;
    cv::imencode(".jpg", Image, imgbuff, param);

    // clear and initlaize sending buffer
    if (!databuff.empty())
        databuff.clear();

    // 1. Add size value of image data (integer)
    int szImage = imgbuff.size();
    databuff.insert(databuff.end(), (unsigned char *)&szImage, (unsigned char *)&szImage + sizeof(int));

    // 2. Add Face retion info
    unsigned char *ptr_face = (unsigned char *)fr.data();
    int facesize = fr.size() * sizeof(FaceRegion);
    databuff.insert(databuff.end(), ptr_face, ptr_face + facesize);

    // 3. Add image data (jpg type)
    databuff.insert(databuff.end(), imgbuff.begin(), imgbuff.end());

    datasize = htonl(databuff.size());

    printf("========\n");
    printf("imgsize size: %d, face size: %d, total size: %d, datasize: %d\n", szImage, facesize, databuff.size(), datasize);

    //imagesize=htonl(imgbuff.size()); // convert image size to network format
    if (WriteDataTcp(TcpConnectedPort, (unsigned char *)&datasize, sizeof(datasize)) != sizeof(datasize))
    {
        printf("here is an error\n");
        return (-1);
    }
    return (WriteDataTcp(TcpConnectedPort, databuff.data(), databuff.size()));
}
//-----------------------------------------------------------------
// END TcpSendFaceData
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// TcpRecvImageFaceData -
//-----------------------------------------------------------------
bool TcpRecvFaceData(TTcpConnectedPort *TcpConnectedPort, cv::Mat *Image, std::vector<struct FaceRegion> *fr, int *countUnknown)
{
    unsigned char *imagebuff = NULL;
    unsigned char *databuff = NULL;
    int imagesize = 0;
    unsigned int datasize;

    //    int numUnknown = 0; // number of unregistered people

    if (ReadDataTcp(TcpConnectedPort, (unsigned char *)&datasize, sizeof(datasize)) != sizeof(datasize))
        return false;
    datasize = ntohl(datasize); // convert image size to host format

    if (datasize < 0)
        return false;

    databuff = new (std::nothrow) unsigned char[datasize];
    if (databuff == NULL)
        return false;

    if ((ReadDataTcp(TcpConnectedPort, databuff, datasize)) == datasize)
    {
        // 1. Get size value of image data (integer)
        //imagesize = buff[0] + (buff[1]<<8) + (buff[2]<<16) + (buff[3]<<24);
        imagesize = 0;
        for (int i = 0; i < sizeof(int); i++)
        {
            imagesize += (databuff[i] << (8 * i));
        }

        if (imagesize <= 0)
        {
            goto finalize;
        }

        // 2. Get Face region info
        int facesize, numFace;
        facesize = (int)datasize - imagesize - sizeof(int);
        numFace = facesize / sizeof(FaceRegion);

        // for no face detected, just pass to get next frame
        if (numFace < 0)
        {
            goto finalize;
        }
        else if (numFace > 0)
        {
            FaceRegion *pFace;
            pFace = new FaceRegion[numFace];
            memcpy(pFace, databuff + sizeof(int), facesize);
            (*countUnknown) = 0;
            for (int i = 0; i < numFace; i++)
            {
                fr->push_back(pFace[i]); // add to vector of FaceRigion
                if (!pFace[i].isRegistered)
                    (*countUnknown)++;
            }
            if (pFace)
            {
                delete[] pFace;
                pFace = NULL;
            } // free
        }

        // 3. Get image data (jpg type)
        imagebuff = new unsigned char[imagesize];
        memcpy(imagebuff, databuff + sizeof(int) + facesize, imagesize);

        // verifying whether the format of image data is jpeg
        if (!isJpegFormat(imagebuff, imagesize))
        {
            printf("isJpegFormat - Failed! - buf[1]: 0x%x\n", imagebuff[1]);
            goto finalize;
        }
        // printf("=========\n");
        // printf("data size = %d, image size = %d, face size = %d\n", datasize, imagesize, facesize);

        // printf("convert image to mat format\n", frameNum);
        cv::imdecode(cv::Mat(imagesize, 1, CV_8UC1, imagebuff), cv::IMREAD_COLOR, Image);

        return true;
    }
finalize:
    if (databuff)
        delete[] databuff;
    databuff = NULL;
    if (imagebuff)
        delete[] imagebuff;
    imagebuff = NULL;

    return false;
}
//-----------------------------------------------------------------
// END TcpRecvImageFaceData
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// END of File
//-----------------------------------------------------------------
