#!/bin/bash
DIR="/home/donghyuk/ca2"
INT_DIR="/home/donghyuk/ca2/intermediate"
KEY_LEN="4096"
LEAF_KEY_LEN="2048"

# make directories to work from
mkdir -p ${DIR}/{certs,crl,newcerts,private}
chmod 700 ${DIR}/private
touch ${DIR}/index.txt
echo 1000 > ${DIR}/serial

# Create your very own Root Certificate Authority
openssl genrsa -aes256 -out ${DIR}/private/ca.key.pem ${KEY_LEN}

chmod 400 ${DIR}/private/ca.key.pem

# Self-sign your Root Certificate Authority
# Since this is private, the details can be as bogus as you like

openssl req -config ${DIR}/openssl.cnf \
  -key ${DIR}/private/ca.key.pem \
  -new -x509 -days 7300 -sha256 -extensions v3_ca \
  -out ${DIR}/certs/ca.cert.pem \
  -subj "/C=KR/ST=Seoul/L=Gangnam/O=LGE/CN=5verflow_root"

chmod 444 ${DIR}/certs/ca.cert.pem

echo ${DIR}/certs/ca.cert.pem

mkdir ${INT_DIR}
mkdir -p ${INT_DIR}/{certs,crl,csr,newcerts,private}
chmod 700 ${INT_DIR}/private
touch ${INT_DIR}/index.txt
echo 1000 > ${INT_DIR}/serial

echo 1000 > ${INT_DIR}/crlnumber
cp ${DIR}/int_openssl.cnf ${INT_DIR}/openssl.cnf

# Create a Device Certificate for each domain,
# such as example.com, *.example.com, awesome.example.com
# NOTE: You MUST match CN to the domain name or ip address you want to use

# Create the intermediate key
openssl genrsa -aes256 \
  -out ${INT_DIR}/private/intermediate.key.pem ${KEY_LEN}

chmod 400 ${INT_DIR}/private/intermediate.key.pem

# Create a request from your Device, which your Root CA will sign
openssl req -config ${INT_DIR}/openssl.cnf -new -sha256 \
	-key ${INT_DIR}/private/intermediate.key.pem \
	-out ${INT_DIR}/csr/intermediate.csr.pem \
	-subj "/C=KR/ST=Seoul/L=Gangnam/O=LGE/CN=192.168.0.100"

openssl ca -config ${DIR}/openssl.cnf -extensions v3_intermediate_ca \
	-days 3650 -notext -md sha256 \
	-in ${INT_DIR}/csr/intermediate.csr.pem \
	-out ${INT_DIR}/certs/intermediate.cert.pem

chmod 444 ${INT_DIR}/certs/intermediate.cert.pem

## Create the certificate chain file
cat ${INT_DIR}/certs/intermediate.cert.pem \
${DIR}/certs/ca.cert.pem > ${INT_DIR}/certs/ca-chain.cert.pem
chmod 444 ${INT_DIR}/certs/ca-chain.cert.pem


## Sign server and client certificates
openssl genrsa -aes256 \
      -out ${INT_DIR}/private/leaf.key.pem ${LEAF_KEY_LEN}

openssl req -config ${INT_DIR}/openssl.cnf \
      -key ${INT_DIR}/private/leaf.key.pem \
      -new -sha256 -out ${INT_DIR}/csr/leaf.csr.pem \
      -subj "/C=KR/ST=Seoul/L=Gangnam/O=LGE/CN=192.168.0.155"

openssl ca -config ${INT_DIR}/openssl.cnf \
      -extensions usr_cert -days 375 -notext -md sha256 \
      -in ${INT_DIR}/csr/leaf.csr.pem \
      -out ${INT_DIR}/certs/leaf.cert.pem

chmod 444 ${INT_DIR}/certs/leaf.cert.pem

cp ${INT_DIR}/private/leaf.key.pem ${INT_DIR}/private/leaf.key.pem.enc
openssl rsa -in ${INT_DIR}/private/leaf.key.pem.enc -out ${INT_DIR}/private/leaf.key.pem

chmod 400 ${INT_DIR}/private/leaf.key.pem
