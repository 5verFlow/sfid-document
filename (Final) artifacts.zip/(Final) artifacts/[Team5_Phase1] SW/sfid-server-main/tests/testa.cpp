#include "gtest/gtest.h"

TEST(testA, test1) {
    EXPECT_EQ (0, 0);
    EXPECT_EQ (true, true);
    EXPECT_NE (true, false);
}
