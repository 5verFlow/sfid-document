# TensorRT L2-Norm Helper
The L2-Norm TensorRT plugin was originally implemented in this repo: https://github.com/r7vme/tensorrt_l2norm_helper
