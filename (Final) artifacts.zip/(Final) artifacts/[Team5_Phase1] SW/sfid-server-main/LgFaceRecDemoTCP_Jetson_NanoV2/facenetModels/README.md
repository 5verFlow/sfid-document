# faceNet models folder
add parsed facenet.uff to this folder
