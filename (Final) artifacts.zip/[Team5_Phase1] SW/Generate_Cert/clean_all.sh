#!/bin/bash
rm -rf certs/ crl/ newcerts/ private/ intermediate/ index.* serial*

