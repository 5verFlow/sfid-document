#ifndef COMM_H
#define COMM_H

#include <QObject>
#include <QVariant>

#include <opencv2/core/core.hpp>

#include <iostream>

#include "NetworkTCP.h"
#include "SecureCTX.h"
#include "SecureTCP.h"
#include "TcpSendRecvJpeg.h"
#include "Video.h"

class Comm : public QObject
{
    Q_OBJECT

public:
    static Comm &instance();

    void initTLS();
    void setVideo(Video *video);

protected:
    Comm();

    bool connect(const char *ip, const char *port, const bool tls);
    void close();

    TTcpConnectedPort *TcpConnectedPort = NULL;

    SSL *ssl = NULL;

    Video *video = NULL;

private:
    static SSL_CTX *ctx;
};

#endif // COMM_H
