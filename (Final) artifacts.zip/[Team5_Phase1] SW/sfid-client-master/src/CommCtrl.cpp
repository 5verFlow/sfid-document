#include "CommCtrl.h"

typedef struct
{
    uint16_t msgType;
    uint16_t dataLen;
} TClientMsgHeader;

#define BUF_SIZE 512

CommCtrl::CommCtrl()
{
}

CommCtrl &CommCtrl::instance()
{
    static CommCtrl *instance = new CommCtrl();
    return *instance;
}

void CommCtrl::cppSlotStartCommCtrl(QVariant ip, QVariant port, QVariant tls)
{
    std::cout << "cppSlotStartCommCtrl call" << std::endl;

    auto std_str_ip = ip.toString().toStdString();
    auto std_str_port = port.toString().toStdString();

    std::cout << "ip: " << std_str_ip << std::endl;
    std::cout << "port: " << std_str_port << std::endl;

    connect(std_str_ip.c_str(), std_str_port.c_str(), tls == 1);
}

void CommCtrl::cppSlotStopCommCtrl()
{
    std::cout << "cppSlotStopCommCtrl call" << std::endl;

    close();
}

void CommCtrl::cppSlotSendCtrlMode(QVariant mode)
{
    std::cout << "cppSlotSendCtrlMode call" << std::endl;

    auto int_mode = mode.toInt();

    std::cout << "mode: " << int_mode << std::endl;

    switch (int_mode)
    {
    case 0:
        sendCtrl(E_MSG_MODE_LIVE, NULL);
        break;
    case 1:
        sendCtrl(E_MSG_MODE_PLAYBACK, NULL);
        break;
    case 2:
        sendCtrl(E_MSG_MODE_REGISTER, NULL);
        break;
    }
}

void CommCtrl::cppSlotSendCtrlRegister(QVariant personName)
{
    std::cout << "cppSlotsendCtrlRegister call" << std::endl;

    auto std_str_person_name = personName.toString().toStdString();

    std::cout << "personName: " << std_str_person_name << std::endl;

    registerPerson(std_str_person_name.c_str());
}

bool CommCtrl::sendCtrl(const CTRL_MSG_TYPE msgType, const char *data)
{
    unsigned char sendBuf[BUF_SIZE];
    memset(sendBuf, 0, BUF_SIZE);

    TClientMsgHeader header;
    header.msgType = htons(msgType);
    if (data == NULL)
    {
        header.dataLen = htons(0);
        memcpy(sendBuf, (char *)&header, sizeof(header));
    }
    else
    {
        header.dataLen = htons(strlen(data) + 1);
        memcpy(sendBuf, (char *)&header, sizeof(header));
        memcpy(sendBuf + sizeof(header), data, strlen(data) + 1);
    }

    int retval = 0;
    if (ssl != NULL)
    {
        retval = SSL_WriteDataTcp(ssl, TcpConnectedPort, sendBuf, sizeof(sendBuf));
    }
    else
    {
        retval = WriteDataTcp(TcpConnectedPort, sendBuf, sizeof(sendBuf));
    }
    if (retval == -1)
    {
        printf("send failed.\n");
    }
    else
    {
        printf("send success. size: %d\n", retval);
    }

    return true;
}

bool CommCtrl::registerPerson(const char *data)
{
    int countUnknown = *(video->getCountUnknown());
    if (countUnknown == 0)
    {
        std::cout << "No unregistered person is detected" << std::endl;
        return false;
    }
    else if (countUnknown > 1)
    {
        std::cout << "Try again. There are many unregistered persons." << std::endl;
        return false;
    }

    sendCtrl(E_MSG_REGISTER, data);
}
