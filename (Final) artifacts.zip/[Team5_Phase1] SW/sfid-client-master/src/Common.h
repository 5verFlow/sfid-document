#ifndef COMMON_H
#define COMMON_H

bool isJpegFormat(unsigned char *buff, int sz);

#define MAX_NAME_LEN 256

struct FaceRegion
{
    int x1, x2, y1, y2; // left, right, top, bottom
    bool isRegistered;  // whether the detected face is for registered persion
    char userName[MAX_NAME_LEN];
};

#endif // COMMON_H
