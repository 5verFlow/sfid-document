#ifndef COMMDATA_H
#define COMMDATA_H

#include <QObject>
#include <QVariant>

#include <opencv2/core/core.hpp>

#include <iostream>

#include "Comm.h"

class CommData : public Comm
{
    Q_OBJECT

public:
    static CommData &instance();

public slots:
    void cppSlotStartCommData(QVariant ip, QVariant port, QVariant tls);
    void cppSlotStopCommData();
    void cppSlotReadData();

private:
    CommData();

    bool readData();
};

#endif // COMMDATA_H
