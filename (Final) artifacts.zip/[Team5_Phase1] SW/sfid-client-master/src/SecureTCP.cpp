//------------------------------------------------------------------------------------------------
// File: SecureTCP.cpp
// Project: LG Exec Ed Program
// Versions:
// 1.0 June 2021 - initial version
// Send and receives OpenCV Mat Images in a Tcp Stream commpressed as Jpeg images using TLS
//------------------------------------------------------------------------------------------------
#include <opencv2/highgui/highgui.hpp>

#include "SecureTCP.h"

static int SSL_init_values[2] = {cv::IMWRITE_JPEG_QUALITY, 80}; //default(95) 0-100
static std::vector<int> SSL_param(&SSL_init_values[0], &SSL_init_values[0] + 2);
static std::vector<uchar> SSL_databuff; //buffer for coding
static std::vector<uchar> SSL_imgbuff;  //buffer for coding

//-----------------------------------------------------------------
// SSL_WriteDataTcp - Writes the specified amount TCP data
//-----------------------------------------------------------------
ssize_t SSL_WriteDataTcp(SSL *ssl, TTcpConnectedPort *TcpConnectedPort, unsigned char *data, size_t length)
{
    ssize_t total_bytes_written = 0;
    ssize_t bytes_written;
    while (total_bytes_written != length)
    {
        bytes_written = SSL_write(ssl, (char *)(data + total_bytes_written), length - total_bytes_written);
        if (bytes_written == -1)
        {
            printf("SSL Send Failure\n");
            return (-1);
        }
        total_bytes_written += bytes_written;
    }
    return (total_bytes_written);
}
//-----------------------------------------------------------------
// END SSL_WriteDataTcp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// SSL_ReadDataTcp - Reads the specified amount TCP data
//-----------------------------------------------------------------
ssize_t SSL_ReadDataTcp(SSL *ssl, TTcpConnectedPort *TcpConnectedPort, unsigned char *data, size_t length)
{
    ssize_t bytes;

    for (size_t i = 0; i < length; i += bytes)
    {
        if ((bytes = SSL_read(ssl, (char *)(data + i), length - i)) == -1)
        {
            printf("SSL Read Failure\n");
            return (-1);
        }
    }
    return (length);
}
//-----------------------------------------------------------------
// END SSL_ReadDataTcp
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// SSL_TcpSendFaceData - Sends a Open CV Mat Image commressed as a
// jpeg image and face region data in side a TCP Stream on the specified TCP local port
// and Destination. return bytes sent on success and -1 on failure
//-----------------------------------------------------------------
int SSL_TcpSendFaceData(SSL *ssl, TTcpConnectedPort *TcpConnectedPort, cv::Mat Image, std::vector<struct FaceRegion> fr)
{
    unsigned int datasize;
    cv::imencode(".jpg", Image, SSL_imgbuff, SSL_param);

    // clear and initlaize sending buffer
    if (!SSL_databuff.empty())
        SSL_databuff.clear();

    // 1. Add size value of image data (integer)
    int szImage = SSL_imgbuff.size();
    SSL_databuff.insert(SSL_databuff.end(), (unsigned char *)&szImage, (unsigned char *)&szImage + sizeof(int));

    // 2. Add Face retion info
    unsigned char *ptr_face = (unsigned char *)fr.data();
    int facesize = fr.size() * sizeof(FaceRegion);
    SSL_databuff.insert(SSL_databuff.end(), ptr_face, ptr_face + facesize);

    // 3. Add image data (jpg type)
    SSL_databuff.insert(SSL_databuff.end(), SSL_imgbuff.begin(), SSL_imgbuff.end());

    datasize = htonl(SSL_databuff.size());

    printf("========\n");
    printf("imgsize size: %d, face size: %d, total size: %ld, datasize: %d\n",
           szImage, facesize, SSL_databuff.size(), datasize);

    //imagesize=htonl(imgbuff.size()); // convert image size to network format
    if (SSL_WriteDataTcp(ssl, TcpConnectedPort, (unsigned char *)&datasize, sizeof(datasize)) != sizeof(datasize))
    {
        printf("here is an error\n");
        return (-1);
    }
    return (SSL_WriteDataTcp(ssl, TcpConnectedPort, SSL_databuff.data(), SSL_databuff.size()));
}

//-----------------------------------------------------------------
// SSL_TcpSendImageAsJpeg - Sends a Open CV Mat Image commressed as a
// jpeg image in side a TCP Stream on the specified TCP local port
// and Destination. return bytes sent on success and -1 on failure
//-----------------------------------------------------------------
int SSL_TcpSendImageAsJpeg(SSL *ssl, TTcpConnectedPort *TcpConnectedPort, cv::Mat Image)
{
    unsigned int imagesize;
    cv::imencode(".jpg", Image, SSL_imgbuff, SSL_param);
    imagesize = htonl(SSL_imgbuff.size()); // convert image size to network format

    if (SSL_WriteDataTcp(ssl, TcpConnectedPort, (unsigned char *)&imagesize, sizeof(imagesize)) != sizeof(imagesize))
    {
        printf("Return -1\n");
        return (-1);
    }
    return (SSL_WriteDataTcp(ssl, TcpConnectedPort, SSL_imgbuff.data(), SSL_imgbuff.size()));
}

//-----------------------------------------------------------------
// END TcpSendImageAsJpeg
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// TcpRecvImageAsJpeg - Sends a Open CV Mat Image commressed as a
// jpeg image in side a TCP Stream on the specified TCP local port
// returns true on success and false on failure
//-----------------------------------------------------------------
bool SSL_TcpRecvImageAsJpeg(SSL *ssl, TTcpConnectedPort *TcpConnectedPort, cv::Mat *Image)
{
    unsigned int imagesize;
    unsigned char *buff; /* receive buffer */

    if (SSL_ReadDataTcp(ssl, TcpConnectedPort, (unsigned char *)&imagesize, sizeof(imagesize)) != sizeof(imagesize))
        return (false);

    imagesize = ntohl(imagesize); // convert image size to host format

    if (imagesize < 0)
        return false;

    buff = new (std::nothrow) unsigned char[imagesize];
    if (buff == NULL)
        return false;

    if ((SSL_ReadDataTcp(ssl, TcpConnectedPort, buff, imagesize)) == imagesize)
    {
        cv::imdecode(cv::Mat(imagesize, 1, CV_8UC1, buff), cv::IMREAD_COLOR, Image);
        delete[] buff;
        if (!(*Image).empty())
            return true;
        else
            return false;
    }
    delete[] buff;
    return false;
}

//-----------------------------------------------------------------
// END TcpRecvImageAsJpeg
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// SSL_TcpRecvImageFaceData -
//-----------------------------------------------------------------
bool SSL_TcpRecvFaceData(SSL *ssl, TTcpConnectedPort *TcpConnectedPort, cv::Mat *Image, std::vector<struct FaceRegion> *fr, int *countUnknown)
{
    unsigned char *imagebuff = NULL;
    unsigned char *databuff = NULL;
    int imagesize = 0;
    unsigned int datasize;

    //    int numUnknown = 0; // number of unregistered people

    if (SSL_ReadDataTcp(ssl, TcpConnectedPort, (unsigned char *)&datasize, sizeof(datasize)) != sizeof(datasize))
        return false;
    datasize = ntohl(datasize); // convert image size to host format

    if (datasize < 0)
        return false;

    databuff = new (std::nothrow) unsigned char[datasize];
    if (databuff == NULL)
        return false;

    if ((SSL_ReadDataTcp(ssl, TcpConnectedPort, databuff, datasize)) == datasize)
    {
        // 1. Get size value of image data (integer)
        //imagesize = buff[0] + (buff[1]<<8) + (buff[2]<<16) + (buff[3]<<24);
        imagesize = 0;
        for (int i = 0; i < sizeof(int); i++)
        {
            imagesize += (databuff[i] << (8 * i));
        }

        if (imagesize <= 0)
        {
            goto finalize;
        }

        // 2. Get Face region info
        int facesize, numFace;
        facesize = (int)datasize - imagesize - sizeof(int);
        numFace = facesize / sizeof(FaceRegion);

        // for no face detected, just pass to get next frame
        if (numFace < 0)
        {
            goto finalize;
        }
        else if (numFace > 0)
        {
            FaceRegion *pFace;
            pFace = new FaceRegion[numFace];
            memcpy(pFace, databuff + sizeof(int), facesize);
            (*countUnknown) = 0;
            for (int i = 0; i < numFace; i++)
            {
                fr->push_back(pFace[i]); // add to vector of FaceRigion
                if (!pFace[i].isRegistered)
                    (*countUnknown)++;
            }
            if (pFace)
            {
                delete[] pFace;
                pFace = NULL;
            } // free
        }

        // 3. Get image data (jpg type)
        imagebuff = new unsigned char[imagesize];
        memcpy(imagebuff, databuff + sizeof(int) + facesize, imagesize);

        // verifying whether the format of image data is jpeg
        if (!isJpegFormat(imagebuff, imagesize))
        {
            printf("isJpegFormat - Failed! - buf[1]: 0x%x\n", imagebuff[1]);
            goto finalize;
        }
        // printf("=========\n");
        // printf("data size = %d, image size = %d, face size = %d\n", datasize, imagesize, facesize);

        // printf("convert image to mat format\n", frameNum);
        cv::imdecode(cv::Mat(imagesize, 1, CV_8UC1, imagebuff), cv::IMREAD_COLOR, Image);

        return true;
    }
finalize:
    if (databuff)
        delete[] databuff;
    databuff = NULL;
    if (imagebuff)
        delete[] imagebuff;
    imagebuff = NULL;

    return false;
}

//-----------------------------------------------------------------
// END of File
//-----------------------------------------------------------------
