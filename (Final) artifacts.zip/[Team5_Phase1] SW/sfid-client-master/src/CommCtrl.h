#ifndef COMMCTRL_H
#define COMMCTRL_H

#include <QObject>
#include <QVariant>

#include <opencv2/core/core.hpp>

#include <iostream>

#include "Comm.h"

enum CTRL_MSG_TYPE
{
    E_MSG_MODE_LIVE = 0,
    E_MSG_MODE_PLAYBACK = 1,
    E_MSG_MODE_REGISTER = 2,
    E_MSG_REGISTER = 3,
};

class CommCtrl : public Comm
{
    Q_OBJECT

public:
    static CommCtrl &instance();

public slots:
    void cppSlotStartCommCtrl(QVariant ip, QVariant port, QVariant tls);
    void cppSlotStopCommCtrl();
    void cppSlotSendCtrlMode(QVariant mode);
    void cppSlotSendCtrlRegister(QVariant personName);

private:
    CommCtrl();

    bool sendCtrl(const CTRL_MSG_TYPE msgType, const char *data);
    bool registerPerson(const char *data);
};

#endif // COMMCTRL_H
