//------------------------------------------------------------------------------------------------
// File: SecureTCP.h
// Project: LG Exec Ed Program
// Versions:
// 1.0 June 2021 - initial version
// Provides the Context Initialization for TLS Connection
//------------------------------------------------------------------------------------------------

#ifndef __SecureCtxH
#define __SecureCtxH

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/ct.h>

SSL_CTX* InitServerCTX(void);
SSL_CTX* InitClientCTX(void);
void SSL_LoadCert(SSL_CTX* ctx, const char* CertFile, const char* KeyFile, const char* CaFile);
#ifdef LOG_OPENSSL
void CT_Log_Start(void);
void CT_Log_Stop(void);
#endif

#endif
//------------------------------------------------------------------------------------------------
//END of Include
//------------------------------------------------------------------------------------------------
