#pragma once

#include <stdio.h>
#include <syslog.h>
#include <stdarg.h>

namespace sfid {
    namespace sflog {


enum {
	LDEF,
	LIMG,
	LCAM,
	LCOM,
	LCON,
};
	class SFLogger {
            static const char *PRE[5];
            public:
                SFLogger(int f = LDEF) {
                    if (f < LDEF || f > LCON) {
                        f = LDEF;
                    }
                    facility = f;
                }

                int facility;

                void emer(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_ALERT | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }

                void alert(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_ALERT | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }
                void crit(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_CRIT | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }
                void err(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_ERR | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }
                void warn(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_WARNING | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }
                void noti(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_NOTICE | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }
                void info(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_INFO | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }
                void debug(const char *format, ...) {
                    char buf[256] = {0, };
                    va_list argptr;

                    va_start(argptr, format);
                    vsnprintf(buf, 255, format, argptr);
                    syslog(LOG_DEBUG | LOG_LOCAL0, "%s %s", PRE[facility], buf);
                    va_end(argptr);
                }
        };
        const char *SFLogger::PRE[] = { "[DEF]", "[IMG]", "[CAM]", "[COMM]", "[CONN]" };
    }
}
