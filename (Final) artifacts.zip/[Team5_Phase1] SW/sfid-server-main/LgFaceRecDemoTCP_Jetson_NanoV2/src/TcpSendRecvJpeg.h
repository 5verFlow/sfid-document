//------------------------------------------------------------------------------------------------
// File: TcpSendRecvJpeg.h
// Project: LG Exec Ed Program
// Versions:
// 1.0 April 2017 - initial version
// Provides the ability to send and receive jpeg images
//------------------------------------------------------------------------------------------------
#ifndef TcpSendRecvJpegH
#define TcpSendRecvJpegH

#include <opencv2/core/core.hpp>
#include "NetworkTCP.h"

enum CONN_MODE {
	E_CONN_TCP = 0,
	E_CONN_TLS = 1
};

enum CRTL_MSG_TYPE {
	E_MSG_LIVE = 0,
	E_MSG_PLAYBACK = 1,
	E_MSG_REGISTER = 2,
	E_MSG_ADD_USER = 3
};

enum OP_MODE {
	E_MODE_LIVE = 0,
	E_MODE_PLAYBACK = 1,
	E_MODE_REGISTER = 2,
	E_MODE_ADD_USER = 3
};

typedef struct {
	uint16_t	msgType;
	uint16_t	dataLen;
	//char	data[];
} TClientMsg;


#ifdef SEND_METADATA
#include "common.h"

int TcpSendFaceData(TTcpConnectedPort * TcpConnectedPort, cv::Mat Image, std::vector<struct FaceRegion> fr);
#endif

#ifdef RECV_METADATA
#define MAX_NAME_LEN 256
struct FaceRegion {
	int x1, x2, y1, y2; // left, right, top, bottom
	bool isRegistered;	// whether the detected face is for registered persion
	char userName[MAX_NAME_LEN];
};

bool TcpRecvFaceData(TTcpConnectedPort * TcpConnectedPort,unsigned char** pp_buf, size_t* p_length);
#endif

int TcpSendImageAsJpeg(TTcpConnectedPort * TcpConnectedPort, cv::Mat Image);
bool TcpRecvImageAsJpeg(TTcpConnectedPort * TcpConnectedPort,cv::Mat *Image);

#endif
//------------------------------------------------------------------------------------------------
//END of Include
//------------------------------------------------------------------------------------------------
