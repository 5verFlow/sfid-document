//------------------------------------------------------------------------------------------------
// File: SecureTCP.h
// Project: LG Exec Ed Program
// Versions:
// 1.0 June 2021 - initial version
// Provides the ability to securely send and receive jpeg images
//------------------------------------------------------------------------------------------------

#ifndef __SecureTCPH
#define __SecureTCPH

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <opencv2/core/core.hpp>
#include "NetworkTCP.h"

#ifdef SEND_METADATA
#include "common.h"

int SSL_TcpSendFaceData(SSL* ssl, TTcpConnectedPort * TcpConnectedPort, cv::Mat Image, std::vector<struct FaceRegion> fr);
#endif

ssize_t SSL_ReadDataTcp(SSL* ssl, TTcpConnectedPort *TcpConnectedPort,unsigned char *data, size_t length);
ssize_t SSL_WriteDataTcp(SSL* ssl, TTcpConnectedPort *TcpConnectedPort,unsigned char *data, size_t length);
int SSL_TcpSendImageAsJpeg(SSL* ssl, TTcpConnectedPort * TcpConnectedPort, cv::Mat Image);
bool SSL_TcpRecvImageAsJpeg(SSL* ssl, TTcpConnectedPort * TcpConnectedPort,cv::Mat *Image);

bool SSL_TcpRecvFaceData(SSL* ssl, TTcpConnectedPort * TcpConnectedPort,unsigned char** pp_buf, size_t* p_length);

#ifdef TEST_CODE
int SSL_TcpSendData(SSL* ssl, TTcpConnectedPort * TcpConnectedPort, const char* pData, const size_t uSize) const;
int SSL_TcpSendData_Test(SSL* ssl, TTcpConnectedPort * TcpConnectedPort);

#endif


#endif
//------------------------------------------------------------------------------------------------
//END of Include
//------------------------------------------------------------------------------------------------
