# sfid-server
 Special Face ID Server

# how to build
<pre>
    $ make build && cd build
    $ cmake ..
    $ make
</pre>
 // then you can find binary at build/bin
 
<pre>
    // please init submodule once like following
    $ git submodule init
    $ git submodule update
</pre>

 
# Files
## extern
 3rd party

## tests
 gtest



